#ifndef USER_MANAGEMENT_H
#define USER_MANAGEMENT_H

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

string user = "juyip";
//users: juyip@1 stewie@12345

//0:exit, 1:signup, 2:wrong password, 3:successful login
int user_login(){
    cout << "Please enter your username: \n(or type 'exit' to quit)\n(or type 'new' to sign up)" << endl;
    cin >> user;
    if(user == "exit") {return 0;}
    else if(user == "new") {return 1;}
    else {
        ifstream file("users.txt");
        string info;
        int present_password;
        bool found = false;
        while(file >> info){
            string prestent_user = info.substr(0, info.find("@"));
            present_password =  stoi(info.substr(info.find("@")+1));
            if(prestent_user == user){
                found = true;
                break;
            }
        }
        file.close();
        if(!found){
            cout << "User not found. Please sign up first." << endl;
            return 2;
        }

        cout << "Welcome, " << user << "!" << endl;
        cout << "Please enter your password: " << endl;
        string password;
        cin >> password;
        int hash_password = 0; //TODO: hash password
        for(int i=0; i<password.length(); i++){
            hash_password = hash_password*31 + password[i];
        }
        if(present_password == hash_password){
            cout << "Login successfully!" << endl;
            return 3;
        }
        else{
            cout << "unable to login: Wrong password." << endl;
            return 2;
        }
    }
}

bool silent_login(string username, string password){
        ifstream file("users.txt");
        string info;
        int present_password;
        bool found = false;
        while(file >> info){
            string prestent_user = info.substr(0, info.find("@"));
            present_password =  stoi(info.substr(info.find("@")+1));
            if(prestent_user == username){
                found = true;
                break;
            }
        }
        file.close();
        if(!found){
            return false;
        }
        int hash_password = 0; //TODO: hash password
        for(int i=0; i<password.length(); i++){
            hash_password = hash_password*31 + password[i];
        }

        if(present_password == hash_password){
            return true;
        }
        else{
            return false;
        }
}

//0:exit, 2:wrong username, 3:successful signup
int signup(){
    cout << "Please enter your username: (type 'exit' to quit)" << endl;
    cin >> user;
    if(user.find("@")!= string::npos){
        cout << "Invalid username. Please try again." << endl;
        return 2;
    }
    if(user == "exit") {return 0;}
    if(user == "new"){
        cout << "Invalid username. Please try again." << endl;
        return 2;
    }
    ifstream file("users.txt");
    string info;
    bool found = false;
    while(file >> info){
        string prestent_user = info.substr(0, info.find("@"));
        if(prestent_user == user){
            found = true;
            break;
        }
    }
    file.close();
    if(found){
        cout << "User already exists. Please try again." << endl;
        return 2;
    }


    cout << "Please enter your password: " << endl;
    string password;
    cin >> password;
    int hash_password = 0; //TODO: hash password
    for(int i=0; i<password.length(); i++){
        hash_password = hash_password*31 + password[i];
    }
    ofstream outfile("users.txt", ios_base::app);
    outfile << ' ' <<user << "@" << hash_password;
    outfile.close();
    cout << "Sign up successfully!" << endl;
    return 3;
}


#endif